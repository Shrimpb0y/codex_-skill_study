---
name: skill-mindmap
description: Generate an offline Markmap mindmap for a chapter completed through the skill-study workflow. Use when the user explicitly invokes /skill_mindmap chapXXX, $skill-mindmap chapXXX, or asks to turn a previously studied chapter knowledge framework into chapXXX.md and chapXXX.html. This skill must follow a matching completed /skill_study chapter rather than operate on unrelated material.
---

# Skill Mindmap

Convert a completed `skill-study` chapter framework into concise Markdown and a self-contained offline Markmap HTML file.

## Invocation Contract

Accept one chapter argument:

```text
/skill_mindmap chap3
```

Normalize an optional `.md` suffix and validate the resulting name against:

```regex
^[A-Za-z0-9_-]+$
```

Reject absolute paths, path separators, `..`, and missing arguments.

## Study Prerequisite

Use this skill only after the matching chapter has been studied through `skill-study`.

Confirm that the current conversation contains a completed knowledge framework for the requested chapter. The framework should include the chapter structure, key concepts, exam focus, confusing pairs, vocabulary, and relevant case studies.

If the requested chapter does not match any completed study context, stop and respond:

```text
No completed study context was found for <chapter>.
Complete /skill_study with the matching chapter courseware first.
```

Do not silently build a mindmap from an unrelated file or invent missing chapter content.

## Build the Markdown

Create `<chapter>.md` in the active workspace from the completed study framework. Do not mechanically copy slide text.

Use this hierarchy:

```markdown
---
markmap:
  colorFreezeLevel: 2
  initialExpandLevel: 3
  maxWidth: 280
---

# Chapter title

## Major topic

### Subtopic

- Definition
- Key point
- Example
- Exam note
```

Apply these rules:

- Keep one concept per node.
- Preserve important English technical terms.
- Use short phrases instead of lecture paragraphs.
- Include major processes, classifications, relationships, examples, and exam distinctions.
- Put confusing pairs and exam-ready distinctions in dedicated branches.
- Keep the source lecture material primary.
- Inspect an existing `<chapter>.md` before replacing it; preserve relevant user edits and update only what the completed framework requires.

## Generate the Offline Mindmap

Use `scripts/generate_mindmap.ps1` after `<chapter>.md` is ready.

Call `codex_app.load_workspace_dependencies` when Node.js is not on `PATH`, then pass its Node executable to the script.

Example:

```powershell
& 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' `
  -NoProfile `
  -ExecutionPolicy Bypass `
  -File '<skill-dir>\scripts\generate_mindmap.ps1' `
  -Chapter chap3 `
  -Workspace '<workspace>' `
  -NodePath '<bundled-node-path>'
```

The script locates a local `markmap-cli`, runs it with `--offline --no-open`, and writes `<chapter>.html` beside the Markdown file.

Never install or download Markmap unless the user explicitly asks. If no local Markmap CLI exists, report the checked locations and ask the user to provide or install it.

## Verify and Deliver

Require all of the following before reporting success:

- `<chapter>.md` exists and contains the chapter title.
- `<chapter>.html` exists and is non-empty.
- The HTML contains Markmap initialization and an SVG container.
- The HTML contains no external HTTP(S) script sources.
- The major framework branches appear in the output.

Return clickable paths to both files. Mention that the HTML is self-contained and works offline.

## Output Lifecycle

```text
/skill_study + ChapXXX courseware
-> teach and grade
-> complete chapter knowledge framework

/skill_mindmap chapXXX
-> validate matching study context
-> create chapXXX.md
-> generate offline chapXXX.html
-> verify and return both files
```
