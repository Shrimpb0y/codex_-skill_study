# Assessment Rubric

## Grading Priorities

Grade answers in this order:

1. Conceptual correctness.
2. Coverage of required points.
3. Correct technical terminology.
4. Example quality.
5. Exam-ready English expression.
6. Grammar and clarity.

## Feedback Pattern

Use this pattern for most answer reviews:

```text
总体评价
逐题批改
更标准答案
易错点
建议背诵表达
评分
```

Keep the tone supportive and concrete. Do not only say "correct" or "wrong"; explain what makes the answer usable or incomplete.

## Common Fixes

- If the user gives a category instead of an example, ask for or provide a concrete example.
- If the user mixes two concepts, separate them with a short contrast table.
- If the user writes informal English, preserve the idea and convert it into exam style.
- If the user copies a model answer, explain the logic behind it so they can adapt it to case-study questions.
- If the user answers in Chinese, accept it for understanding and provide an English exam version.

## Scoring Guide

- `9-10/10`: accurate, complete, exam-ready.
- `7-8/10`: concept mostly correct, needs terminology or completeness fixes.
- `5-6/10`: partial understanding, missing key points or examples.
- `<5/10`: concept confusion; reteach before moving on.

## Exam Answer Upgrade Pattern

Transform rough answers into:

```text
Definition:
Reason:
Example:
Effect or limitation:
```

For comparison questions:

```text
Concept A:
Concept B:
Main difference:
Example:
```
