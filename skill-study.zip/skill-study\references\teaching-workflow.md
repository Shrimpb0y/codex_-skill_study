# Teaching Workflow

## New Chapter Intake

1. Confirm the file path and type.
2. Extract text from all slides/pages.
3. Identify image-only or diagram-heavy pages and inspect them visually.
4. Build a chapter map:
   - title and topic
   - major sections
   - likely exam concepts
   - diagrams/tables that need explanation
5. Start with the first logical slide/page chunk.

## Chunk Teaching Pattern

For each chunk:

1. State the slide/page range and topic.
2. Explain the main idea before details.
3. Translate and preserve important English terms.
4. Break definitions into components.
5. Use simple real-world examples.
6. Connect back to previous concepts.
7. Provide exam-ready wording.
8. End with 3-6 practice questions.

## Chapter-End Output

At the end of a chapter, produce:

```text
Chapter Summary
Key Concepts
Exam Focus
Confusing Pairs
Important Vocabulary
Mind Map Input Outline
Next Step
```

The `Mind Map Input Outline` should be hierarchical and concise:

```text
Chapter Title
- Major Concept
  - Subconcept
  - Definition
  - Example
  - Exam note
```

End with:

```text
本章学习已完成。如果你要生成思维导图，可以发送 /skill_mindMap。
```

## Continuation Rules

If the user says:

- `继续`: continue from the next uncompleted chunk.
- `跳过练习`: move to the next chunk without grading.
- `复习`: summarize and quiz the requested range.
- `讲慢一点`: reduce chunk size and add more examples.
- `只要考试版`: focus on definitions, comparisons, and answer templates.
